@echo off
setlocal
cd /d "%~dp0.."
title Minecraft 26.3 - Servidor de Testes
call gradlew.bat runServer
pause
endlocal
