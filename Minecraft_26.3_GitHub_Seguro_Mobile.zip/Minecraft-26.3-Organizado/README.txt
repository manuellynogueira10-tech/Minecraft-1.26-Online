============================================================
       MINECRAFT JAVA 26.3 - PROJETO ORGANIZADO DE TESTES
============================================================

Bem-vindo ao projeto organizado do Minecraft Java 26.3!

Esta estrutura foi preparada para desenvolvimento, testes e estudos,
mantendo o conteudo do jogo intacto. A reorganizacao altera somente
onde os arquivos ficam e como o Gradle os encontra.

NAO sao alterados por esta reorganizacao:
- Interface original do Minecraft
- Texturas originais
- Sons e musicas originais
- Modelos e animacoes
- Blocos, itens e entidades
- Geracao de mundo
- Receitas, loot tables e dados do jogo
- Mecanicas e comportamento vanilla

============================================================
ESTRUTURA
============================================================

Game-Src\
  Codigo-fonte Java decompilado do Minecraft.

Game-Resources\
  Assets e data do jogo: texturas, modelos, sons, shaders, idiomas,
  receitas, tags, estruturas e demais recursos.

Game-Runtime\
  Arquivos criados durante a execucao: mundos, logs, screenshots,
  options.txt, resourcepacks e arquivos do cliente/servidor.

Game-Launcher\
  Atalhos para iniciar o cliente e o servidor.

Game-Scripts\
  Scripts para preparar, atualizar e migrar o projeto.

Game-Backups\
  Backups criados antes de atualizacoes ou migracoes.

Game-Utils\
  Metadados e arquivos auxiliares da estrutura organizada.

============================================================
PRIMEIRA PREPARACAO
============================================================

Execute:

  Game-Scripts\Preparar-Projeto.bat

ou pelo PowerShell:

  .\gradlew.bat setup

Depois, para iniciar:

  Game-Launcher\Iniciar-Minecraft.bat

ou:

  .\gradlew.bat runClient

============================================================
MIGRANDO UM PROJETO ANTIGO
============================================================

Se voce ja possui uma pasta src\main\java e src\main\resources,
execute pelo PowerShell:

  powershell -ExecutionPolicy Bypass -File ".\Game-Scripts\Migrar-Projeto-Atual.ps1"

O script cria um backup antes de copiar qualquer coisa e NAO apaga a
pasta src antiga automaticamente.

============================================================
IMPORTANTE
============================================================

Minecraft e propriedade da Mojang Studios / Microsoft.
Este projeto e uma estrutura de desenvolvimento e testes, nao um
produto oficial da Mojang ou Microsoft.

Sempre mantenha backups antes de modificar codigo ou recursos.
============================================================

============================================================
SEGURANCA / GITHUB / MOBILE (edicao reforcada)
============================================================
- Rode Game-Scripts\Validar-Seguranca.bat antes de publicar.
- Rode Game-Scripts\Importar-para-GitHub.bat para configurar o repositorio.
- Leia README-GITHUB.md e SECURITY.md.
- Controles mobile: Mobile\Controls\default.json.
- Bridge opcional usando KeyMapping do proprio Minecraft: Mobile\Native-Bridge\MobileInputBridge.java.
- Nenhum recurso visual, textura, HUD ou regra do jogo foi substituido por esta edicao.
