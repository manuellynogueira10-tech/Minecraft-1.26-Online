# Security Policy

## Scope

This repository contains build/orchestration code. Generated Minecraft source, assets, saves, credentials, Microsoft tokens and private keys must not be committed to a public repository.

## Reporting

If you find a vulnerability, do not open an issue containing credentials, tokens or private data. Use GitHub's private vulnerability reporting feature when enabled, or contact the repository owner privately.

## Security defaults

- GitHub Actions receive read-only repository permissions unless a human explicitly changes them.
- Checkout credentials are not persisted in CI.
- The Gradle distribution is pinned by SHA-256.
- Mojang version metadata is downloaded only over HTTPS from expected Mojang hosts and is checked against the SHA-1 supplied by Mojang's version manifest.
- `Game-Src`, `Game-Resources`, runtime files, backups and secrets are ignored by Git by default.
- The automated version-bump workflow is manual-only and cannot push changes.

Run `./gradlew securityCheck githubSafetyCheck` before publishing.
