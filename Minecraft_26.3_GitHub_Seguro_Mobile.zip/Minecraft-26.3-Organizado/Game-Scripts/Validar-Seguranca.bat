@echo off
setlocal
cd /d "%~dp0.."
call gradlew.bat --no-daemon securityCheck githubSafetyCheck
pause
endlocal
