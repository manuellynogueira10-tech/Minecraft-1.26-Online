$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$LegacySrc = Join-Path $Root 'src'
$NewSrc = Join-Path $Root 'Game-Src'
$NewRes = Join-Path $Root 'Game-Resources'
$Backups = Join-Path $Root 'Game-Backups'
$Utils = Join-Path $Root 'Game-Utils'
$Runtime = Join-Path $Root 'Game-Runtime'

Write-Host '==============================================='
Write-Host ' Migracao para a estrutura organizada'
Write-Host ' Nenhum recurso do Minecraft sera convertido.'
Write-Host '==============================================='
Write-Host ''

if (!(Test-Path $LegacySrc)) {
    Write-Host 'Nenhuma pasta src antiga foi encontrada. Nada para migrar.'
    exit 0
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $Backups "Antes-da-Migracao-$stamp"
New-Item -ItemType Directory -Force $backup | Out-Null
Copy-Item $LegacySrc (Join-Path $backup 'src') -Recurse -Force
Write-Host "OK: backup criado em $backup"

New-Item -ItemType Directory -Force $NewSrc,$NewRes,$Utils,$Runtime | Out-Null

$java = Join-Path $LegacySrc 'main\java'
$res = Join-Path $LegacySrc 'main\resources'

if (Test-Path $java) {
    Copy-Item (Join-Path $java '*') $NewSrc -Recurse -Force
    Write-Host 'OK: codigo Java copiado para Game-Src'
}
if (Test-Path $res) {
    Copy-Item (Join-Path $res '*') $NewRes -Recurse -Force
    Write-Host 'OK: resources copiados para Game-Resources sem alteracao de conteudo'
}

$oldVersion = Join-Path $LegacySrc '.mc-version'
if (Test-Path $oldVersion) {
    Copy-Item $oldVersion (Join-Path $Utils '.mc-version') -Force
    Write-Host 'OK: versao do projeto preservada'
}

if (Test-Path (Join-Path $Root 'run')) {
    Copy-Item (Join-Path $Root 'run\*') $Runtime -Recurse -Force
    Write-Host 'OK: runtime antigo copiado para Game-Runtime'
}

Write-Host ''
Write-Host 'Migracao concluida.'
Write-Host 'A pasta src antiga NAO foi apagada. Depois de testar, voce pode move-la para Game-Backups.'
