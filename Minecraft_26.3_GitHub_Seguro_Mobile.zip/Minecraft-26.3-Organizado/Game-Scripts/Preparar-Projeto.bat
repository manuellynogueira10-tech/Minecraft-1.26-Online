@echo off
setlocal
cd /d "%~dp0.."
title Preparar Minecraft 26.3
call gradlew.bat setup
pause
endlocal
