@echo off
setlocal
cd /d "%~dp0.."
title Atualizar Minecraft
call gradlew.bat updateSources
pause
endlocal
