@echo off
setlocal
cd /d "%~dp0.."
set /p REPO=URL do repositorio GitHub (https://github.com/usuario/repositorio.git): 
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Importar-para-GitHub.ps1" -RepositoryUrl "%REPO%"
pause
endlocal
