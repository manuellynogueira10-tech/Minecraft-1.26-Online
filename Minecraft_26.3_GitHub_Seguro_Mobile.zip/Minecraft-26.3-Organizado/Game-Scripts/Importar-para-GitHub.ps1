param(
    [Parameter(Mandatory=$true)]
    [string]$RepositoryUrl,
    [switch]$Push
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw 'Git nao esta instalado ou nao esta no PATH.'
}

Write-Host 'Validando seguranca do projeto...'
& .\gradlew.bat --no-daemon securityCheck
if ($LASTEXITCODE -ne 0) { throw 'securityCheck falhou.' }

if (-not (Test-Path '.git')) {
    git init
    git branch -M main
}

# Generated Mojang source/resources are intentionally ignored by default.
git add .

$trackedGenerated = @(git ls-files Game-Src Game-Resources | Where-Object { $_ -and -not $_.EndsWith('.keep') })
if ($trackedGenerated.Count -gt 0) {
    throw 'Por seguranca/licenciamento, Game-Src/Game-Resources gerados nao podem ser publicados por este script.'
}

$hasHead = $true
try { git rev-parse --verify HEAD *> $null } catch { $hasHead = $false }
if (-not $hasHead) {
    git commit -m 'Minecraft 26.3 organizado - base segura para GitHub'
} elseif (git status --porcelain) {
    git commit -m 'Atualiza estrutura segura e suporte mobile'
}

$existing = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0) {
    git remote set-url origin $RepositoryUrl
} else {
    git remote add origin $RepositoryUrl
}

Write-Host ''
Write-Host "Repositorio configurado: $RepositoryUrl"
if ($Push) {
    Write-Host 'Enviando branch main...'
    git push -u origin main
} else {
    Write-Host 'Nada foi enviado ainda. Revise e depois rode:'
    Write-Host '  git push -u origin main'
}
