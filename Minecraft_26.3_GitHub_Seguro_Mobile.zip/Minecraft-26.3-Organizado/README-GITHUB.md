# Minecraft 26.3 — Projeto organizado e endurecido para GitHub

Esta edição preserva o comportamento, recursos e aparência do Minecraft. As alterações deste pacote ficam na **infraestrutura do projeto**: segurança do build/GitHub, organização e uma camada mobile opcional de entrada.

## O que foi reforçado

- Gradle 9.8.0 com checksum SHA-256 da distribuição.
- Metadados de versão Mojang baixados apenas por HTTPS de hosts esperados e validados pelo SHA-1 publicado pela Mojang.
- GitHub Actions com `contents: read`, credenciais de checkout não persistidas e timeout de job.
- Atualização automática com permissão de escrita foi removida; o verificador de versão é manual.
- `securityCheck` procura padrões comuns de tokens e chaves privadas.
- `githubSafetyCheck` impede publicação acidental do código/assets gerados do Minecraft.
- `.gitignore` exclui runtime, backups, Game-Src/Game-Resources gerados, credenciais e builds.

## Mobile sem mudar o jogo

`Mobile/Controls/default.json` fornece uma camada de toque para launchers compatíveis. Os controles são convertidos em teclado/mouse e chegam ao sistema nativo de input do Minecraft.

`Mobile/Native-Bridge/MobileInputBridge.java` é opcional e usa diretamente `net.minecraft.client.KeyMapping` e os `KeyMapping` existentes em `Minecraft.options`. Ele **não desenha UI, não troca textura, não altera HUD e não recria lógica de gameplay**.

Para instalar o bridge após gerar `Game-Src`:

```powershell
.\gradlew.bat installMobileInputBridge
.\gradlew.bat classes
```

## Preparar projeto

```powershell
.\gradlew.bat setup
```

## Validar antes do GitHub

```powershell
.\gradlew.bat securityCheck githubSafetyCheck
```

## Importar para GitHub no Windows

Crie primeiro um repositório **vazio** no GitHub. Depois execute:

```text
Game-Scripts\Importar-para-GitHub.bat
```

Cole a URL, por exemplo:

```text
https://github.com/SEU_USUARIO/Minecraft-26.3-Organizado.git
```

O script prepara o commit e configura `origin`, mas não faz `push` automaticamente. Depois de revisar:

```powershell
git push -u origin main
```

> Importante: este pacote deixa `Game-Src` e `Game-Resources` gerados fora de um GitHub público por padrão. Minecraft e o conteúdo gerado pertencem à Mojang/Microsoft. Se você mantiver modificações de código do jogo, use um repositório privado e respeite os termos aplicáveis.
