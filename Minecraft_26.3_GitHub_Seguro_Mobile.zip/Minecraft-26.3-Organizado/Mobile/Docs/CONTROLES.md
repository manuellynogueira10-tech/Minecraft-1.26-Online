# Controles mobile sem alterar o visual do Minecraft

A implementação foi separada em duas camadas para preservar integralmente a interface e a lógica do jogo:

1. **Overlay de toque do launcher (`Mobile/Controls/default.json`)** — desenha apenas os controles Android por cima da janela. Nenhuma textura, tela, HUD ou recurso do Minecraft é substituído.
2. **Bridge nativa opcional (`Mobile/Native-Bridge/MobileInputBridge.java`)** — delega ações diretamente aos `KeyMapping` já existentes em `Minecraft.options` (`keyUp`, `keyJump`, `keyAttack`, etc.). Isso reaproveita a própria lógica de input do Minecraft em vez de recriar movimento/ataque/voo.

O bridge não é instalado automaticamente. Depois de `setup`, se uma integração Android precisar chamar diretamente as teclas do Minecraft, rode:

```bash
./gradlew installMobileInputBridge
./gradlew classes
```

Para launchers que já convertem toque em teclado/mouse, **não é necessário instalar o bridge**; basta importar `Mobile/Controls/default.json`. O Minecraft recebe os mesmos eventos de teclado/mouse e continua usando sua implementação nativa de `KeyMapping`.

## Entrada simultânea

O layout não bloqueia teclado ou mouse físico. Touch, teclado e mouse podem coexistir; quem processa a ação final continua sendo o Minecraft.

## Criativo

O botão de pulo envia `Espaço`, portanto o voo criativo continua obedecendo ao comportamento nativo do jogo (duplo toque/duplo espaço, subir segurando pulo e descer com agachar), sem lógica paralela criada neste repositório.
