package local.mobile;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/**
 * Optional platform bridge for mobile/touch front-ends.
 *
 * It deliberately contains no renderer, textures or replacement gameplay logic.
 * Touch front-ends call setDown(Action, boolean); Minecraft's own KeyMapping then
 * drives movement, attack/use, jumping, crouching and sprint exactly as keyboard
 * input does. Physical keyboard input remains supported by Minecraft in parallel.
 */
public final class MobileInputBridge {
    private MobileInputBridge() {}

    public enum Action {
        FORWARD,
        BACK,
        LEFT,
        RIGHT,
        JUMP,
        SNEAK,
        SPRINT,
        ATTACK,
        USE
    }

    private static KeyMapping mapping(Action action) {
        Minecraft minecraft = Minecraft.getInstance();
        return switch (action) {
            case FORWARD -> minecraft.options.keyUp;
            case BACK -> minecraft.options.keyDown;
            case LEFT -> minecraft.options.keyLeft;
            case RIGHT -> minecraft.options.keyRight;
            case JUMP -> minecraft.options.keyJump;
            case SNEAK -> minecraft.options.keyShift;
            case SPRINT -> minecraft.options.keySprint;
            case ATTACK -> minecraft.options.keyAttack;
            case USE -> minecraft.options.keyUse;
        };
    }

    public static void setDown(Action action, boolean down) {
        mapping(action).setDown(down);
    }

    public static boolean isDown(Action action) {
        return mapping(action).isDown();
    }

    /** Releases every touch-held action, e.g. when Android loses focus. */
    public static void releaseAll() {
        for (Action action : Action.values()) {
            mapping(action).setDown(false);
        }
    }
}
